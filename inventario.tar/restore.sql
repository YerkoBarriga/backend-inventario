--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE inventario;
--
-- Name: inventario; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE inventario WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Mexico.1252';


ALTER DATABASE inventario OWNER TO postgres;

\connect inventario

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id_categoria integer NOT NULL,
    nombre character varying(60) NOT NULL,
    detalle text NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categorias_id_categoria_seq OWNER TO postgres;

--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_categoria_seq OWNED BY public.categorias.id_categoria;


--
-- Name: piezas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.piezas (
    id_pieza integer NOT NULL,
    id_categoria integer,
    nombre character varying(60) NOT NULL,
    precio integer NOT NULL
);


ALTER TABLE public.piezas OWNER TO postgres;

--
-- Name: piezas_id_pieza_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.piezas_id_pieza_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.piezas_id_pieza_seq OWNER TO postgres;

--
-- Name: piezas_id_pieza_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.piezas_id_pieza_seq OWNED BY public.piezas.id_pieza;


--
-- Name: provedor_pieza; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provedor_pieza (
    id_provedor integer NOT NULL,
    id_pieza integer NOT NULL,
    cantidad integer NOT NULL,
    fecha date NOT NULL
);


ALTER TABLE public.provedor_pieza OWNER TO postgres;

--
-- Name: provedor_pieza_id_pieza_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provedor_pieza_id_pieza_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provedor_pieza_id_pieza_seq OWNER TO postgres;

--
-- Name: provedor_pieza_id_pieza_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provedor_pieza_id_pieza_seq OWNED BY public.provedor_pieza.id_pieza;


--
-- Name: provedor_pieza_id_provedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provedor_pieza_id_provedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provedor_pieza_id_provedor_seq OWNER TO postgres;

--
-- Name: provedor_pieza_id_provedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provedor_pieza_id_provedor_seq OWNED BY public.provedor_pieza.id_provedor;


--
-- Name: provedores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.provedores (
    id_provedor integer NOT NULL,
    nombre character varying(60) NOT NULL,
    direccion text NOT NULL,
    ciudad character varying(100) NOT NULL,
    provincia character varying(60) NOT NULL
);


ALTER TABLE public.provedores OWNER TO postgres;

--
-- Name: provedores_id_provedor_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.provedores_id_provedor_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.provedores_id_provedor_seq OWNER TO postgres;

--
-- Name: provedores_id_provedor_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.provedores_id_provedor_seq OWNED BY public.provedores.id_provedor;


--
-- Name: categorias id_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id_categoria SET DEFAULT nextval('public.categorias_id_categoria_seq'::regclass);


--
-- Name: piezas id_pieza; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piezas ALTER COLUMN id_pieza SET DEFAULT nextval('public.piezas_id_pieza_seq'::regclass);


--
-- Name: provedor_pieza id_provedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedor_pieza ALTER COLUMN id_provedor SET DEFAULT nextval('public.provedor_pieza_id_provedor_seq'::regclass);


--
-- Name: provedor_pieza id_pieza; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedor_pieza ALTER COLUMN id_pieza SET DEFAULT nextval('public.provedor_pieza_id_pieza_seq'::regclass);


--
-- Name: provedores id_provedor; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedores ALTER COLUMN id_provedor SET DEFAULT nextval('public.provedores_id_provedor_seq'::regclass);


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (id_categoria, nombre, detalle) FROM stdin;
\.
COPY public.categorias (id_categoria, nombre, detalle) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: piezas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.piezas (id_pieza, id_categoria, nombre, precio) FROM stdin;
\.
COPY public.piezas (id_pieza, id_categoria, nombre, precio) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: provedor_pieza; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provedor_pieza (id_provedor, id_pieza, cantidad, fecha) FROM stdin;
\.
COPY public.provedor_pieza (id_provedor, id_pieza, cantidad, fecha) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: provedores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.provedores (id_provedor, nombre, direccion, ciudad, provincia) FROM stdin;
\.
COPY public.provedores (id_provedor, nombre, direccion, ciudad, provincia) FROM '$$PATH$$/3352.dat';

--
-- Name: categorias_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_categoria_seq', 4, true);


--
-- Name: piezas_id_pieza_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.piezas_id_pieza_seq', 7, true);


--
-- Name: provedor_pieza_id_pieza_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.provedor_pieza_id_pieza_seq', 1, false);


--
-- Name: provedor_pieza_id_provedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.provedor_pieza_id_provedor_seq', 1, false);


--
-- Name: provedores_id_provedor_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.provedores_id_provedor_seq', 3, true);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id_categoria);


--
-- Name: piezas piezas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piezas
    ADD CONSTRAINT piezas_pkey PRIMARY KEY (id_pieza);


--
-- Name: provedor_pieza provedor_pieza_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedor_pieza
    ADD CONSTRAINT provedor_pieza_pkey PRIMARY KEY (id_provedor, id_pieza);


--
-- Name: provedores provedores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedores
    ADD CONSTRAINT provedores_pkey PRIMARY KEY (id_provedor);


--
-- Name: piezas piezas_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.piezas
    ADD CONSTRAINT piezas_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias(id_categoria);


--
-- Name: provedor_pieza provedor_pieza_id_pieza_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedor_pieza
    ADD CONSTRAINT provedor_pieza_id_pieza_fkey FOREIGN KEY (id_pieza) REFERENCES public.piezas(id_pieza);


--
-- Name: provedor_pieza provedor_pieza_id_provedor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.provedor_pieza
    ADD CONSTRAINT provedor_pieza_id_provedor_fkey FOREIGN KEY (id_provedor) REFERENCES public.provedores(id_provedor);


--
-- PostgreSQL database dump complete
--

